# Databricks notebook source
# DBTITLE 1,Title header
# MAGIC %md
# MAGIC # Create Denormalized Fact Transactions View
# MAGIC
# MAGIC Rebuilds `ecommerce.gold.fact_transactions_denorm` — the Gold fact table joined with the Product and Date dimensions. Final task of the ETL pipeline.

# COMMAND ----------

# DBTITLE 1,Create denormalized view
# MAGIC %sql
# MAGIC -- STEP 5: Denormalized view — Gold fact joined with Product and Date dimensions
# MAGIC CREATE OR REPLACE VIEW ecommerce.gold.fact_transactions_denorm AS
# MAGIC SELECT
# MAGIC     f.date_id,
# MAGIC     f.transaction_date,
# MAGIC     f.transaction_ts,
# MAGIC     f.transaction_id,
# MAGIC     f.seq_no,
# MAGIC     f.customer_id,
# MAGIC     f.product_id,
# MAGIC     p.sku,
# MAGIC     p.category_code,
# MAGIC     p.category_name,
# MAGIC     p.brand_code,
# MAGIC     p.brand_name,
# MAGIC     f.channel,
# MAGIC     f.coupon_code,
# MAGIC     f.coupon_flag,
# MAGIC     f.unit_price_currency,
# MAGIC     f.quantity,
# MAGIC     f.unit_price,
# MAGIC     f.gross_amount,
# MAGIC     f.discount_percent,
# MAGIC     f.discount_amount,
# MAGIC     f.tax_amount,
# MAGIC     f.net_amount,
# MAGIC     f.net_amount_inr,
# MAGIC     d.year,
# MAGIC     d.month_name,
# MAGIC     d.quarter,
# MAGIC     d.week,
# MAGIC     d.day_name,
# MAGIC     d.is_weekend,
# MAGIC     date_format(f.transaction_date, 'yyyy-MM') AS month,
# MAGIC     hour(f.transaction_ts) AS hour_of_day
# MAGIC FROM ecommerce.gold.gld_fact_order_items f
# MAGIC LEFT JOIN ecommerce.gold.gld_dim_products p
# MAGIC     ON f.product_id = p.product_id
# MAGIC LEFT JOIN ecommerce.gold.gld_dim_date d
# MAGIC     ON f.date_id = d.date_id

# COMMAND ----------

